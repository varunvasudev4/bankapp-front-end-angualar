import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  currentUserName:any
  currentUserID:any
  //database
  accounts:any = {
    1000:{accno:1000,accname:"Max",accpwrd:1000,accbal:5000,transaction:[]},
    1001:{accno:1001,accname:"Maxwell",accpwrd:1001,accbal:6000,transaction:[]},
    1002:{accno:1002,accname:"Alan",accpwrd:1002,accbal:4000,transaction:[]}
    
  }

  constructor() {
    this.getData()
   }

  

  login(accno:any,accpwrd:any){
    var accs = this.accounts
    if(accno in accs){
      if(accpwrd == accs[accno]['accpwrd']){
        this.currentUserName=accs[accno]['accname']
        this.currentUserID=accno
        this.saveData()
        return true
      }else{
        return false
      }
    }else{
      return false
    }
  }


  register(accno:any,accname:any,accpwrd:any){
    var acc = this.accounts
    if(accno in acc){
      return false
    }else{
      acc[accno]={
        accno,
        accname,
        accpwrd,
        accbal:2000,
        transaction:[]
      }
      console.log(this.accounts);
      this.saveData()
      return true
    }
  }

  

  deposit(accnum:any,accamt:any){
    var acc = this.accounts
    acc[accnum]['accbal']+=Number(accamt)
    acc[accnum]['transaction'].push({
      type:"Credit",
      amount:accamt
    })
    this.saveData()
    alert("Deposited successfully"+` new balance ${acc[accnum]['accbal']}`)
  }

  widraw(accnum:any,accamt:any){
    var acc = this.accounts
    if(acc[accnum]['accbal']>accamt){
      acc[accnum]['accbal']-=Number(accamt)
      acc[accnum]['transaction'].push({
        type:"Debit",
        amount:accamt
      })
      this.saveData()
      alert(`${accamt} Widrawed successfully`+` new balance ${acc[accnum]['accbal']}`)
    }else{
      alert("Insufficient Balance")
    }
  }
  
  getTrans(){
    var acc = this.accounts
    var accno = this.currentUserID
    return acc[accno]['transaction']
  }

  saveData(){
    if(this.accounts){
      localStorage.setItem("user",JSON.stringify(this.accounts))
    }
    if(this.currentUserID){
      localStorage.setItem("cuserid",JSON.stringify(this.currentUserID))
    }
    if(this.currentUserName){
      localStorage.setItem("cusername",JSON.stringify(this.currentUserName))
    }
  }

  getData(){
    if(localStorage.getItem("user")){
      this.accounts = JSON.parse(localStorage.getItem('user') || "")
    }
    if(localStorage.getItem("cuserid")){
      this.currentUserID = JSON.parse(localStorage.getItem('cuserid') || "")
    }
    if(localStorage.getItem("cusername")){
      this.currentUserName = JSON.parse(localStorage.getItem('cusername') || "")
    }
  }
}

