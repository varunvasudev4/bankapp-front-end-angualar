import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {




  user = ""

  constructor(private ds: DataService, private fb: FormBuilder,private router:Router) {
    this.user = this.ds.currentUserName
    this.logdate = Date();
  }

  // accnum = ""
  // accpwrd = ""
  // accamt = ""

  dform = this.fb.group({
    accnum :['',[Validators.required,Validators.pattern('[0-9]*')]],
    accpwrd :['',[Validators.required,Validators.pattern('[a-zA-Z0-9]*')]],
    accamt:['',[Validators.required,Validators.pattern('[0-9]*')]]
  })

  // accnum2 = ""
  // accpwrd2 = ""
  // accamt2 = ""

  wform = this.fb.group({
    accnum2 :['',[Validators.required,Validators.pattern('[0-9]*')]],
    accpwrd2 :['',[Validators.required,Validators.pattern('[a-zA-Z0-9]*')]],
    accamt2:['',[Validators.required,Validators.pattern('[0-9]*')]]
  })


  ngOnInit(): void {
    if(!localStorage.getItem('cuserid')){
      //alert("Please Login")
      this.router.navigateByUrl('')
    }

  }


  deposit() {

    if(this.dform.valid){
      const result = this.ds.login(this.dform.value.accnum, this.dform.value.accpwrd)
    if (result) {

      this.ds.deposit(this.dform.value.accnum, this.dform.value.accamt)

    } else {
      alert("Incorrect AccID or Password")
    }
  }else{
    alert("Invalid Form")
  }

  }

  widraw() {
    if(this.wform.valid){
      const result = this.ds.login(this.wform.value.accnum2, this.wform.value.accpwrd2)
    if (result) {

      this.ds.widraw(this.wform.value.accnum2, this.wform.value.accamt2)

    } else {
      alert("Incorrect AccID or Password")
    }
  }else{
    alert("Invalid Form")
  }
  }

  logout(){
    localStorage.removeItem('cuserid');
    localStorage.removeItem('cusername')
    this.router.navigateByUrl('')
  }

  //acno to child
  acno:any

  delpar(){
    this.acno= JSON.parse(localStorage.getItem('cuserid') || "")
  }

  cancel(){
    this.acno=""
  }

  logdate: any
}
